
const FORMSPREE_ENDPOINT = "https://formspree.io/f/your-endpoint"; // replace with your real endpoint

function currency(n){try{return new Intl.NumberFormat(undefined,{style:'currency',currency:'USD'}).format(n)}catch(e){return '$'+n}}

async function getProducts(){
  const res = await fetch('data/products.json', {cache: 'no-store'});
  return await res.json();
}

function tagString(p){
  return [p.category, p.option, p.origin, p.units+' units', p.sku].join(' ').toLowerCase();
}

function cardHTML(p){
  const pct = p.progress_pct || 0;
  const img = (p.images && p.images[0]) || 'assets/og.jpg';
  return `
    <article class="card" data-tags="${tagString(p)}">
      <img src="${img}" alt="${p.name}">
      <div class="body">
        <div class="badge">${p.option.split('—')[0].trim()}</div>
        <div class="badge">${p.option.includes('3 months') ? '3 months' : '6 months'}</div>
        <h3>${p.name}</h3>
        <p class="note">Raise: ${currency(p.raise)} • Close: ${p.close_date}</p>
        <div class="progress"><span style="width:${pct}%"></span></div>
        <p><a class="btn" style="background:#fff;border:1px solid var(--primary);color:var(--primary);padding:8px 12px;border-radius:10px" href="product.html?id=${encodeURIComponent(p.id)}">Details</a></p>
      </div>
    </article>
  `;
}

async function renderOpportunities(){
  const list = await getProducts();
  const container = document.querySelector('#cards');
  container.innerHTML = list.map(cardHTML).join('');
  const filter = document.querySelector('#filter');
  if(filter){
    filter.addEventListener('input', (e)=>{
      const term = e.target.value.toLowerCase();
      container.querySelectorAll('.card').forEach(c=>{
        const tags = c.getAttribute('data-tags')||'';
        c.style.display = tags.includes(term) ? '' : 'none';
      });
    });
  }
}

function row([k,v]){ return `<tr><th>${k}</th><td>${v}</td></tr>`; }

async function renderProduct(){
  const params = new URLSearchParams(location.search);
  const id = params.get('id');
  const list = await getProducts();
  const p = list.find(x=>x.id===id) || list[0];

  const img = (p.images && p.images[0]) || 'assets/og.jpg';
  document.getElementById('p-image').src = img;
  document.getElementById('p-title').textContent = p.name;
  document.getElementById('p-sub').textContent = `${p.category} • ${p.sku}`;
  document.getElementById('p-desc').textContent = p.short_description || '';

  const terms = [
    ['Option', p.option],
    ['Raise', currency(p.raise)],
    ['Close date', p.close_date],
    ['Payout ETA', p.payout_eta],
    ['Origin', p.origin],
    ['Use of funds', p.use_of_funds],
    ['Safeguard', p.safeguard]
  ];
  document.getElementById('p-terms').innerHTML = '<tr><th>Term</th><th>Details</th></tr>' + terms.map(row).join('');

  const km = p.key_metrics || {};
  const metrics = Object.entries(km).map(([k,v])=>[k.replace(/_/g,' ').replace(/\b\w/g,m=>m.toUpperCase()), v]);
  document.getElementById('p-metrics').innerHTML = '<tr><th>Metric</th><th>Value</th></tr>' + metrics.map(row).join('');

  const select = document.getElementById('p-option');
  if(select){
    ['Option A — 10% in 3 months','Option B — 5% guaranteed in 6 months'].forEach(opt=>{
      const op = document.createElement('option');
      op.textContent = opt;
      op.value = opt;
      if(opt===p.option) op.selected = true;
      select.appendChild(op);
    });
  }

  const form = document.getElementById('apply-form');
  if(form){
    form.addEventListener('submit', async (e)=>{
      e.preventDefault();
      const data = Object.fromEntries(new FormData(form).entries());
      try{
        const r = await fetch(FORMSPREE_ENDPOINT, {
          method:'POST',
          headers:{'Accept':'application/json','Content-Type':'application/json'},
          body: JSON.stringify({...data, product_id: p.id})
        });
        if(r.ok){ alert('Thanks! We received your submission. We will follow up shortly.'); form.reset(); }
        else{ alert('Submission failed. Please email invest@dartcollection.com instead.'); }
      }catch(err){ alert('Network error. Please email invest@dartcollection.com.'); }
    });
  }
}

// Contact page form
document.addEventListener('DOMContentLoaded', ()=>{
  const contactForm = document.querySelector('form.apply#apply-form:not(.product)');
  if(contactForm){
    contactForm.addEventListener('submit', async (e)=>{
      e.preventDefault();
      const data = Object.fromEntries(new FormData(contactForm).entries());
      try{
        const r = await fetch(FORMSPREE_ENDPOINT, {
          method:'POST',
          headers:{'Accept':'application/json','Content-Type':'application/json'},
          body: JSON.stringify(data)
        });
        if(r.ok){ alert('Thanks! We received your submission.'); contactForm.reset(); }
        else { alert('Submission failed. Please email invest@dartcollection.com.'); }
      }catch(err){ alert('Network error. Please email invest@dartcollection.com.'); }
    });
  }
});
